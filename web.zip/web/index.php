<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
	<?php include("head.php"); ?>
<body>	
<?php include("main.php"); ?>


</body>
<?php include("footer.php"); ?>
</html>                     