<div class="copyrights">
	 
</div>	
<div class="copyrights" >
	 <p>© 2019 winternet. All Rights Reserved | Design by  <a href="http://winternet.co.in" target="_blank">Winternet</a> </p>
</div>	